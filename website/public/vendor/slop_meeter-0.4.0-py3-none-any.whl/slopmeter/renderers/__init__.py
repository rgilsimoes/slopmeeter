"""Pure report rendering adapters."""
