"""Static, explainable repository checks."""

